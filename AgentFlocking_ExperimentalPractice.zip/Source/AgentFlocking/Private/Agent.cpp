

//includes
#include "Agent.h"
#include "Components/SphereComponent.h"
#include "Components/StaticMeshComponent.h"
#include "Components/ArrowComponent.h" 
#include "AgentSimManager.h"
#include "DrawDebugHelpers.h"
#include "AgentFlocking/AgentFlocking.h" // For the collision avoidance trace channel set in the UE4 settings

AAgent::AAgent()
{
	// Enable the tick
	PrimaryActorTick.bCanEverTick = true;

	// Setup collision component and make it the root
	AgentCollision = CreateDefaultSubobject<USphereComponent>(TEXT("Agent Collision Component"));
	RootComponent = AgentCollision;
	AgentCollision->SetCollisionObjectType(ECC_Pawn);
	AgentCollision->SetCollisionEnabled(ECollisionEnabled::QueryOnly);
	AgentCollision->SetCollisionResponseToAllChannels(ECR_Overlap);

	// Create mesh component for Agent
	// This is set to a sphere mesh
	AgentMesh = CreateDefaultSubobject<UStaticMeshComponent>(TEXT("Agent Mesh Component"));
	AgentMesh->SetupAttachment(RootComponent);
	AgentMesh->SetCollisionEnabled(ECollisionEnabled::NoCollision);
	AgentMesh->SetCollisionResponseToAllChannels(ECR_Ignore);

	// Directional arrow component to show the Agents heading direction
	DirectionalArrow = CreateDefaultSubobject<UArrowComponent>(TEXT("Directional Arrow Component"));
	DirectionalArrow->SetupAttachment(RootComponent);
	// So the arrow can be shown whilst the sim is running
	DirectionalArrow->SetHiddenInGame(false);

	// Create the perception sensor component used to find flockmates to fly with
	PerceptionSensor = CreateDefaultSubobject<USphereComponent>(TEXT("Perception Sensor Component"));
	PerceptionSensor->SetupAttachment(RootComponent);
	PerceptionSensor->SetCollisionEnabled(ECollisionEnabled::QueryOnly);
	PerceptionSensor->SetCollisionResponseToAllChannels(ECR_Ignore);
	PerceptionSensor->SetCollisionResponseToChannel(ECC_Pawn, ECR_Overlap);
	PerceptionSensor->SetSphereRadius(300.0f);

	// Default velocity of Agent
	AgentVelocity = FVector::ZeroVector;
}

void AAgent::BeginPlay()
{
	Super::BeginPlay();

	// Check to see if Agent is owned by valid sim manager
	AAgentSimManager* AgentSimOwner = Cast<AAgentSimManager>(this->GetOwner());
	if (AgentSimOwner)
	{
		// Setting the sim manager
		AgentSimManager = AgentSimOwner;
		// Setting the velocity of the agent based on rotation and speed settings
		AgentVelocity = this->GetActorForwardVector();
		AgentVelocity.Normalize();
		AgentVelocity *= FMath::FRandRange(AgentSimManager->GetMinSpeed(), AgentSimManager->GetMaxSpeed());

		// set agents rotation
		AgentRotation = this->GetActorRotation();
	}
	else
	{
		// Warning as no sim manager has been found
		UE_LOG(LogTemp, Warning, TEXT("No AgentSimManager found for Agent: %s."), *GetName());
	}
}

void AAgent::Tick(float DeltaTime)
{
	Super::Tick(DeltaTime);
 
	// Update agents position every frame
	Steer(DeltaTime);
	// Update agents rotation every frame
	UpdateAgentRotation();
}

// Function to update the Agents rotation
void AAgent::UpdateAgentRotation()
{
	// Rotate towards other Agents current heading smoothly
	AgentRotation = FMath::RInterpTo(AgentRotation, this->GetActorRotation(), GetWorld()->DeltaTimeSeconds, 7.0f);
	this->AgentMesh->SetWorldRotation(AgentRotation);
}

// Function to calculate Seperation forces between the Agents within the flock
FVector AAgent::Separation(TArray<AActor*> Flock)
{
	// Check for valid sim manager
	if (AgentSimManager == nullptr) { return FVector::ZeroVector; }

	// Setting default variables
	FVector SteeringForce = FVector::ZeroVector;
	FVector SeparationDirection = FVector::ZeroVector;
	float ProximityFactor = 0.0f;
	int32 AgentCount = 0;
	 
	// For loop to get all the separation forces for each of the Agent's flockmates
	for (AActor* OverlappedActor : Flock)
	{
		// If overlap is not null or the agent itself continue
		AAgent* Flockmate = Cast<AAgent>(OverlappedActor);
		if (Flockmate != this && Flockmate != nullptr)
		{
			// Check if flockmate is outside the perception fov
			if (FVector::DotProduct(this->GetActorForwardVector(), (Flockmate->GetActorLocation() - this->GetActorLocation()).GetSafeNormal()) <= AgentSimManager->GetSeparationFOV())
			{
				continue;	// Flockmate must be outside perception angle, disregard and continue the loop
			}

			// Get the normalized direction away from nearby Agent
			SeparationDirection = this->GetActorLocation() - Flockmate->GetActorLocation();
			SeparationDirection = SeparationDirection.GetSafeNormal();

			// Get scaling factor based off other Agent's proximity. 
			// 0 = Far away (no separation force) & 1 = Close (full separation force)
			ProximityFactor = 1.0f - (SeparationDirection.Size() / this->PerceptionSensor->GetScaledSphereRadius());

			// Check to see if flockmate's center of mass is outside the perception radius.
			if (ProximityFactor < 0.0f)
			{
				continue;	// Flockmate must be outside perception angle, disregard and continue the loop
			}

			// Add the steering forces of flockmates and increase the flock count
			SteeringForce += (ProximityFactor * SeparationDirection);
			AgentCount++;
		}
	}

	if (AgentCount > 0)
	{
		// Average Separation force of flock
		SteeringForce /= AgentCount;
		SteeringForce.GetSafeNormal() -= this->AgentVelocity.GetSafeNormal();
		SteeringForce *= AgentSimManager->GetSeparationStrength();
		return SteeringForce;
	}
	else
	{
		return FVector::ZeroVector;
	}
}
// Function to calculate Alignment forces between the Agents within the flock
FVector AAgent::Alignment(TArray<AActor*> Flock)
{
	// Check for valid sim manager
	if (AgentSimManager == nullptr) { return FVector::ZeroVector; }

	// Setting default variables
	FVector SteeringForce = FVector::ZeroVector;
	int32 AgentCount = 0.0f;

	// For loop to get all the Alignment forces for each of the Agent's flockmates
	for (AActor* OverlapActor : Flock)
	{
		AAgent* Flockmate = Cast<AAgent>(OverlapActor);
		if (Flockmate != nullptr && Flockmate != this)
		{
			// Check if flockmate is outside the perception fov
			if (FVector::DotProduct(this->GetActorForwardVector(), (Flockmate->GetActorLocation() - this->GetActorLocation()).GetSafeNormal()) <= AgentSimManager->GetAlignmentFOV())
			{
				continue;	// Flockmate must be outside perception angle, disregard and continue the loop
			}
			// Add the steering forces of flockmates and increase the flock count
			SteeringForce += Flockmate->AgentVelocity.GetSafeNormal();
			AgentCount++;
		}
	}

	if (AgentCount > 0)
	{
		// Average Alignment force of flock
		SteeringForce /= AgentCount;
		SteeringForce.GetSafeNormal() -= this->AgentVelocity.GetSafeNormal();
		SteeringForce *= AgentSimManager->GetAlignmentStrength();
		return SteeringForce;
	}
	else
	{
		return FVector::ZeroVector;
	}
}

// Function to calculate Cohesion forces between the Agents within the flock
FVector AAgent::Cohesion(TArray<AActor*> Flock)
{
	// Check for valid sim manager
	if (AgentSimManager == nullptr) { return FVector::ZeroVector; }

	// Setting default variables
	FVector SteeringForce = FVector::ZeroVector;
	FVector AveragePosition = FVector::ZeroVector;
	int32 AgentCount = 0.0f;

	// For loop to get all the Alignment forces for each of the Agent's flockmates
	for (AActor* OverlapActor : Flock)
	{
		AAgent* Flockmate = Cast<AAgent>(OverlapActor);
		if (Flockmate != nullptr && Flockmate != this)
		{
			// Check if flockmate is outside the perception fov
			if (FVector::DotProduct(this->GetActorForwardVector(), (Flockmate->GetActorLocation() - this->GetActorLocation()).GetSafeNormal()) <= AgentSimManager->GetCohesionFOV())
			{
				continue;	// Flockmate must be outside perception angle, disregard and continue the loop
			}
			// Add the steering forces of flockmates and increase the flock count
			AveragePosition += Flockmate->GetActorLocation();
			AgentCount++;
		}
	}

	if (AgentCount > 0)
	{
		// Average Cohesion force of flock
		AveragePosition /= AgentCount;
		SteeringForce = AveragePosition - this->GetActorLocation();
		SteeringForce.GetSafeNormal() -= this->AgentVelocity.GetSafeNormal();
		SteeringForce *= AgentSimManager->GetCohesionStrength();
		return SteeringForce;
	}
	else
	{
		return FVector::ZeroVector;
	}
}

// Function for the Agents behavioural movement
void AAgent::Steer(float DeltaTime)
{
	// Check for valid sim manager
	if (AgentSimManager == nullptr) { return; }
	FVector Acceleration = FVector::ZeroVector;

	// Update Agents position and rotation
	this->SetActorLocation(this->GetActorLocation() + (AgentVelocity * DeltaTime));
	this->SetActorRotation(AgentVelocity.ToOrientationQuat());

	// Apply behavioural forces to Acceleration
	// Find other agents in the general area to navigate with
	TArray<AActor*> Flockmates;
	PerceptionSensor->GetOverlappingActors(Flockmates, TSubclassOf<AAgent>());
	Acceleration += Separation(Flockmates);
	Acceleration += Alignment(Flockmates);
	Acceleration += Cohesion(Flockmates);

	// See if their will be a collision
	if (ImminentCollision())
	{
		// Apply avoidance force to the acceleration variable
		Acceleration += AvoidCollision();

	}

	// Setting the agents velocity
	AgentVelocity += (Acceleration * DeltaTime);
	AgentVelocity = AgentVelocity.GetClampedToSize(AgentSimManager->GetMinSpeed(), AgentSimManager->GetMaxSpeed());
}

// Function for the obstacle avoidance
bool AAgent::ImminentCollision()
{
	// Check for valid sim manager
	if (AgentSimManager == nullptr) { return false; }
	// Check to see if their is more than 0 avoidance sensors
	if (AgentSimManager->GetAvoidanceSensors().Num() > 0)
	{
		// Use forward sensor to check for collision
		// Rotate the first sensor towards forward direction of Agent
		FQuat SensorRot = FQuat::FindBetweenVectors(AgentSimManager->GetAvoidanceSensors()[0], this->GetActorForwardVector());
		FVector NewSensorDir = FVector::ZeroVector;
		NewSensorDir = SensorRot.RotateVector(AgentSimManager->GetAvoidanceSensors()[0]);
		// Set collision properties and params
		FCollisionQueryParams TraceParameters;
		FHitResult Hit;
		// Collision check on the first line trace
		GetWorld()->LineTraceSingleByChannel(Hit, this->GetActorLocation(), this->GetActorLocation() + NewSensorDir * AgentSimManager->GetSensorRadius(), AGENT_COLLISION_AVOIDANCE, TraceParameters);
		// Debug lines showing collision checks
		// Indicates if this hit was a result of blocking collision.

		if (Hit.bBlockingHit)
		{
			DrawDebugLine(GetWorld(), this->GetActorLocation(), this->GetActorLocation() + NewSensorDir * AgentSimManager->GetSensorRadius(), FColor::Red, false, -1.0f, 0, 1.5f);
			DrawDebugSphere(GetWorld(), Hit.ImpactPoint, 8.0f, 12, FColor::Red, false, -1.0f, 0, 1.0f);
		}
		else
		{
			DrawDebugLine(GetWorld(), this->GetActorLocation(), this->GetActorLocation() + NewSensorDir * AgentSimManager->GetSensorRadius(), FColor::Green, false, -1.0f, 0, 1.5f);
		}

		// Check if Agent is inside a object
		if (Hit.bBlockingHit)
		{
			TArray<AActor*> OverlapActors;
			AgentCollision->GetOverlappingActors(OverlapActors);
			for (AActor* OverlapActor : OverlapActors)
			{
				if (Hit.Actor == OverlapActor)
				{
					return false;
				}
			}
		}

		return Hit.bBlockingHit;
	}
	// No sensors to check
	return false;
}

FVector AAgent::AvoidCollision()
{
	// Check for valid sim manager
	if (AgentSimManager == nullptr) { return FVector::ZeroVector; }

	// Setting default variables
	FVector SteeringForce = FVector::ZeroVector;
	FVector NewSensorDir = FVector::ZeroVector;
	FQuat SensorRot = FQuat::FindBetweenVectors(AgentSimManager->GetAvoidanceSensors()[0], this->GetActorForwardVector());
	FCollisionQueryParams TraceParameters;
	FHitResult Hit;


	// Checking for collisions and then steering the Agent out of the way
	for (FVector AvoidanceSensor : AgentSimManager->GetAvoidanceSensors())
	{
		// Rotate the avoidance sensor to align with the Agents heading direction and check again for collisions
		NewSensorDir = SensorRot.RotateVector(AvoidanceSensor);
		GetWorld()->LineTraceSingleByChannel(Hit, this->GetActorLocation(), this->GetActorLocation() + NewSensorDir * AgentSimManager->GetSensorRadius(), AGENT_COLLISION_AVOIDANCE, TraceParameters);
		// Debug lines visualising the new sensor direction and what would be the impact
		if (Hit.bBlockingHit)
		{
			DrawDebugLine(GetWorld(), this->GetActorLocation(), this->GetActorLocation() + NewSensorDir * AgentSimManager->GetSensorRadius(), FColor::Red, false, -1.0f, 0, 1.5f);
			DrawDebugSphere(GetWorld(), Hit.ImpactPoint, 8.0f, 12, FColor::Red, false, -1.0f, 0, 1.0f);
		}
		// Returning the steering forces and visualising the obstacle avoidance using debug lines
		else
		{
			DrawDebugLine(GetWorld(), this->GetActorLocation(), this->GetActorLocation() + NewSensorDir * AgentSimManager->GetSensorRadius(), FColor::Green, false, -1.0f, 0, 1.5f);
			SteeringForce = NewSensorDir.GetSafeNormal() - this->AgentVelocity.GetSafeNormal();
			SteeringForce *= AgentSimManager->GetAvoidanceStrength();
			DrawDebugDirectionalArrow(GetWorld(), this->GetActorLocation(), this->GetActorLocation() + SteeringForce, 5.0f, FColor::Yellow, false, -1.0f, 0, 3.0f);
			return SteeringForce;
		}
	}
	return FVector::ZeroVector;
}


