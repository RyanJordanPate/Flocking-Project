

#include "AgentSpawner.h"
#include "Components/BoxComponent.h"
#include "Components/StaticMeshComponent.h"
#include "Agent.h"
#include "AgentSimManager.h"

AAgentSpawner::AAgentSpawner()
{
	//disable actor ticking
	PrimaryActorTick.bCanEverTick = false;

	//setup cage collision component
	BoxCollision = CreateDefaultSubobject<UBoxComponent>(TEXT("Box Collision Component"));
	RootComponent = BoxCollision;
	BoxCollision->SetBoxExtent(FVector(2500));
	BoxCollision->SetCollisionEnabled(ECollisionEnabled::QueryOnly);
	BoxCollision->SetCollisionResponseToAllChannels(ECR_Ignore);
	BoxCollision->SetCollisionResponseToChannel(ECC_Pawn, ECR_Overlap);
	BoxCollision->SetHiddenInGame(false);

	// Initial size of flock within the cage
	AgentsToSpawn = 0;
}

void AAgentSpawner::BeginPlay()
{
	Super::BeginPlay();

	// Bind collision component overlap event
	if (BoxCollision)
	{
		BoxCollision->OnComponentEndOverlap.AddDynamic(this, &AAgentSpawner::OnBoxOverlapEnd);
	}

	// Spawn preset amount of agents
	SpawnAgents(AgentsToSpawn);
}

// Function to spawn agents on opposite side when leaving the bounds
void AAgentSpawner::OnBoxOverlapEnd(UPrimitiveComponent* OverlappedComponent, AActor* OtherActor, UPrimitiveComponent* OtherComp, int32 OtherBodyIndex)
{
	// Check to see if agent is leaving the bounds
	AAgent* EscapingAgent = Cast<AAgent>(OtherActor);
	if (EscapingAgent)
	{
		if (EscapingAgent->IsActorBeingDestroyed()) { return; }

		FVector NewAgentLocation = EscapingAgent->GetActorLocation();
		// check which side of the bounds the agent is leaving
		// Agent exiting front side
		if (EscapingAgent->GetActorLocation().X > this->GetActorLocation().X + BoxCollision->GetScaledBoxExtent().X)
		{
			// Move Agent to back side
			NewAgentLocation.X = this->GetActorLocation().X - BoxCollision->GetScaledBoxExtent().X;
			NewAgentLocation.Y = FMath::Clamp(NewAgentLocation.Y, this->GetActorLocation().Y - BoxCollision->GetScaledBoxExtent().Y, this->GetActorLocation().Y + BoxCollision->GetScaledBoxExtent().Y);
			NewAgentLocation.Z = FMath::Clamp(NewAgentLocation.Z, this->GetActorLocation().Z - BoxCollision->GetScaledBoxExtent().Z, this->GetActorLocation().Z + BoxCollision->GetScaledBoxExtent().Z);
			EscapingAgent->SetActorLocation(NewAgentLocation);
		}
		// Agent exiting back side
		else if (EscapingAgent->GetActorLocation().X < this->GetActorLocation().X - BoxCollision->GetScaledBoxExtent().X)
		{
			// Move Agent to front side
			NewAgentLocation.X = this->GetActorLocation().X + BoxCollision->GetScaledBoxExtent().X;
			NewAgentLocation.Y = FMath::Clamp(NewAgentLocation.Y, this->GetActorLocation().Y - BoxCollision->GetScaledBoxExtent().Y, this->GetActorLocation().Y + BoxCollision->GetScaledBoxExtent().Y);
			NewAgentLocation.Z = FMath::Clamp(NewAgentLocation.Z, this->GetActorLocation().Z - BoxCollision->GetScaledBoxExtent().Z, this->GetActorLocation().Z + BoxCollision->GetScaledBoxExtent().Z);
			EscapingAgent->SetActorLocation(NewAgentLocation);
		}
		// Agent exiting right side
		else if (EscapingAgent->GetActorLocation().Y > this->GetActorLocation().Y + BoxCollision->GetScaledBoxExtent().Y)
		{
			// Move Agent to left side
			NewAgentLocation.X = FMath::Clamp(NewAgentLocation.X, this->GetActorLocation().X - BoxCollision->GetScaledBoxExtent().X, this->GetActorLocation().X + BoxCollision->GetScaledBoxExtent().X);
			NewAgentLocation.Y = this->GetActorLocation().Y - BoxCollision->GetScaledBoxExtent().Y;
			NewAgentLocation.Z = FMath::Clamp(NewAgentLocation.Z, this->GetActorLocation().Z - BoxCollision->GetScaledBoxExtent().Z, this->GetActorLocation().Z + BoxCollision->GetScaledBoxExtent().Z);
			EscapingAgent->SetActorLocation(NewAgentLocation);
		}
		// Agent exiting left side
		else if (EscapingAgent->GetActorLocation().Y < this->GetActorLocation().Y - BoxCollision->GetScaledBoxExtent().Y)
		{
			// Move Agent to right side
			NewAgentLocation.X = FMath::Clamp(NewAgentLocation.X, this->GetActorLocation().X - BoxCollision->GetScaledBoxExtent().X, this->GetActorLocation().X + BoxCollision->GetScaledBoxExtent().X);
			NewAgentLocation.Y = this->GetActorLocation().Y + BoxCollision->GetScaledBoxExtent().Y;
			NewAgentLocation.Z = FMath::Clamp(NewAgentLocation.Z, this->GetActorLocation().Z - BoxCollision->GetScaledBoxExtent().Z, this->GetActorLocation().Z + BoxCollision->GetScaledBoxExtent().Z);
			EscapingAgent->SetActorLocation(NewAgentLocation);
		}
		// Agent exiting top side
		else if (EscapingAgent->GetActorLocation().Z > this->GetActorLocation().Z + BoxCollision->GetScaledBoxExtent().Z)
		{
			// Move Agent to bottom side
			NewAgentLocation.X = FMath::Clamp(NewAgentLocation.X, this->GetActorLocation().X - BoxCollision->GetScaledBoxExtent().X, this->GetActorLocation().X + BoxCollision->GetScaledBoxExtent().X);
			NewAgentLocation.Y = FMath::Clamp(NewAgentLocation.Y, this->GetActorLocation().Y - BoxCollision->GetScaledBoxExtent().Y, this->GetActorLocation().Y + BoxCollision->GetScaledBoxExtent().Y);
			NewAgentLocation.Z = this->GetActorLocation().Z - BoxCollision->GetScaledBoxExtent().Z;
			EscapingAgent->SetActorLocation(NewAgentLocation);
		}
		// Agent exiting bottom side
		else if (EscapingAgent->GetActorLocation().Z < this->GetActorLocation().Z - BoxCollision->GetScaledBoxExtent().Z)
		{
			// Move Agent to top side
			NewAgentLocation.X = FMath::Clamp(NewAgentLocation.X, this->GetActorLocation().X - BoxCollision->GetScaledBoxExtent().X, this->GetActorLocation().X + BoxCollision->GetScaledBoxExtent().X);
			NewAgentLocation.Y = FMath::Clamp(NewAgentLocation.Y, this->GetActorLocation().Y - BoxCollision->GetScaledBoxExtent().Y, this->GetActorLocation().Y + BoxCollision->GetScaledBoxExtent().Y);
			NewAgentLocation.Z = this->GetActorLocation().Z + BoxCollision->GetScaledBoxExtent().Z;
			EscapingAgent->SetActorLocation(NewAgentLocation);
		}
		// Agent unexpectedly exitted the area, remove Agent from, destroy it, and spawn new one
		// Keep consistency within the simulation
		else
		{
			EscapingAgent->GetAgentSimManager()->RemoveAgent(EscapingAgent);
			GetWorld()->DestroyActor(EscapingAgent);
			SpawnAgents(1);
		}
	}
}

void AAgentSpawner::SpawnAgents(int32 NumAgents)
{
	// Check for valid sim manager
	if (AssignedAgentSimManager == nullptr)
	{
		// Warning for no agent spawner set
		UE_LOG(LogTemp, Warning, TEXT("No AgentSimManager found for Agent spawner: %s."), *GetName());
		return;
	}

	// Check the correct agent type has been set
	if (AgentType == nullptr)
	{
		// Warning for no agent type set
		UE_LOG(LogTemp, Warning, TEXT("AgentType not set for Spawner: %s"), *GetName());
		return;
	}

	// Spawn the agents within the box area
	FVector SpawnLoc = FVector::ZeroVector;
	FRotator SpawnRot = FRotator::ZeroRotator;
	FActorSpawnParameters AgentSpawnParams;
	AgentSpawnParams.SpawnCollisionHandlingOverride = ESpawnActorCollisionHandlingMethod::AlwaysSpawn;
	AgentSpawnParams.Owner = AssignedAgentSimManager;

	for (int i = 0; i < NumAgents; ++i)
	{
		// Spawn all Agents randomly within the box area
		SpawnLoc.X = FMath::FRandRange(-BoxCollision->GetScaledBoxExtent().X, BoxCollision->GetScaledBoxExtent().X);
		SpawnLoc.Y = FMath::FRandRange(-BoxCollision->GetScaledBoxExtent().Y, BoxCollision->GetScaledBoxExtent().Y);
		SpawnLoc.Z = FMath::FRandRange(-BoxCollision->GetScaledBoxExtent().Z, BoxCollision->GetScaledBoxExtent().Z);
		SpawnLoc += this->GetActorLocation();
		SpawnRot = FMath::VRand().ToOrientationRotator();
		AssignedAgentSimManager->AddAgent(GetWorld()->SpawnActor<AAgent>(AgentType, SpawnLoc, SpawnRot, AgentSpawnParams));
	}
}