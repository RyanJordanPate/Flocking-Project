


//includes
#include "AgentSimManager.h"
#include "Components/BillboardComponent.h"
#include "Agent.h"
#include "Kismet/KismetMathLibrary.h"

AAgentSimManager::AAgentSimManager()
{
	// Disable the tick
	PrimaryActorTick.bCanEverTick = false;

	// Create billboard component to easily find the actor in the scene
	AgentSimManagerBillboard = CreateDefaultSubobject<UBillboardComponent>(TEXT("AgentSimManager Billboard Component"));
	RootComponent = AgentSimManagerBillboard;

// DEFAULT VARIABLES

	// Setting the default behavioral strengths
	AlignmentStrength = 200.0f;
	SeparationStrength = 30.0f;
	CohesionStrength = 5.0f;
	AvoidanceStrength = 10000.0f;

	// Setting default behavioural FOV
	SeparationFOV = -1.0f;
	AlignmentFOV = 0.5f;
	CohesionFOV = -0.5f;

	// Setting default speed variables
	MaxSpeed = 700.0f;
	MinSpeed = 300.0f;

	// Setting default avoidance variables
	NumSensors = 100;
	SensorRad = 300.0f;
	BuildAvoidanceSensors();
}

void AAgentSimManager::BeginPlay()
{
	Super::BeginPlay();
}

// Function to add a new agent to the flock
void AAgentSimManager::AddAgent(AAgent* Agent)
{
	if (Agent)
	{
		// Adding agent to the flock
		AgentsInFlock.AddUnique(Agent);
	}
}

// Function to remove agent from the flock
void AAgentSimManager::RemoveAgent(AAgent* Agent)
{
	if (Agent)
	{
		// Removing agent from the flock
		AgentsInFlock.Remove(Agent);
	}
}

// Function to set the max speed of the agents
void AAgentSimManager::SetMaxSpeed(float NewMaxSpeed)
{
	if (NewMaxSpeed < 0)
	{
		// Warning to make sure the max speed is correct
		UE_LOG(LogTemp, Warning, TEXT("Agent max speed is set incorrectly below 0: %s."), *GetName());
		return;
	}

	// Updating the max speed to the new setting
	MaxSpeed = NewMaxSpeed;

	// Check if new Max is lower than Min to avoid errors
	if (MaxSpeed < MinSpeed)
	{
		MinSpeed = MaxSpeed;
	}
}

// Function to set the min speed of the Agents
void AAgentSimManager::SetMinSpeed(float NewMinSpeed)
{
	if (NewMinSpeed < 0)
	{
		// Warning to make sure min speed is set correctly
		UE_LOG(LogTemp, Warning, TEXT("Agent min speed is set incorrectly below 0: %s."), *GetName());
		return;
	}

	// Updating the min speed to the new setting
	MinSpeed = NewMinSpeed;

	// Check if new Min is higher than Max to avoid errors
	if (MinSpeed > MaxSpeed)
	{
		MaxSpeed = MinSpeed;
	}
}

// Functions to update the behavioural strenghts
void AAgentSimManager::SetAlignmentStrength(float NewAlignmentStrength)
{
	AlignmentStrength = NewAlignmentStrength;
}
void AAgentSimManager::SetSeparationStrength(float NewSeparationStrength)
{
	SeparationStrength = NewSeparationStrength;
}
void AAgentSimManager::SetCohesionStrength(float NewCohesionStrength)
{
	CohesionStrength = NewCohesionStrength;
}
void AAgentSimManager::SetAvoidanceStrength(float NewAvoidanceStrength)
{
	AvoidanceStrength = NewAvoidanceStrength;
}

// Function to build the avoidance sensors on the agent used to avoid obstacles
void AAgentSimManager::BuildAvoidanceSensors()
{
	// Empty array for the sensors
	AvoidanceSensors.Empty();

	// Variable angle of rotation on xy plane around z axis
	float theta;
	// Variable angle of rotation (pitch)
	float phi;
	// direction vector pointing from the center to point on sphere surface
	FVector SensorDir;

	for (int32 i = 0; i < NumSensors; ++i)
	{
		// Calculating the spherical coordinates of the direction vectors endpoint
		theta = 2 * UKismetMathLibrary::GetPI() * GoldenRatio * i;
		phi = FMath::Acos(1 - (2 * float(i) / NumSensors));

		// Converting the points on sphere to xyz
		SensorDir.X = FMath::Cos(theta) * FMath::Sin(phi);
		SensorDir.Y = FMath::Sin(theta) * FMath::Sin(phi);
		SensorDir.Z = FMath::Cos(phi);
		// Add direction to list of sensors for avoidance
		AvoidanceSensors.Emplace(SensorDir);
	}
}

