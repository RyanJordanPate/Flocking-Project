

// Actor placed in the level that stores the perception and steering settings of the Agents it controls.
// Used as a way to manipulate the behavior of the entire flock and optimize flock-wide logic changes.

#pragma once

//includes
#include "CoreMinimal.h"
#include "GameFramework/Actor.h"
#include "AgentSimManager.generated.h"

//forward declares
class UBillboardComponent;
class AAgent;

UCLASS()
class AGENTFLOCKING_API AAgentSimManager : public AActor
{
	GENERATED_BODY()

public:
	//default constructor
	AAgentSimManager();

protected:
	// Called on level start or when spawned
	virtual void BeginPlay() override;

// Components
protected:
	// Billboard component to help find the actor within the level
	UPROPERTY(VisibleAnywhere, Category = "Agent|Components")
	UBillboardComponent* AgentSimManagerBillboard;

// Agent Array
protected:
	// Array of agents within the flock
	TArray<AAgent*> AgentsInFlock;

public:
	// Functions to add and remove agents from flock
	void AddAgent(AAgent* Agent);
	void RemoveAgent(AAgent* Agent);

// Movement
protected:
	// Agents maximum and minimum speeds
	UPROPERTY(EditAnywhere, Category = "Agent|Movement", meta = (ClampMin = "0.0"))
	float MaxSpeed;
	UPROPERTY(EditAnywhere, Category = "Agent|Movement", meta = (ClampMin = "0.0"))
	float MinSpeed;

public:
	// Getting Min/Max Speed
	UFUNCTION(BlueprintCallable, Category = "Agent|Movement")
	inline float GetMaxSpeed() { return MaxSpeed; };
	UFUNCTION(BlueprintCallable, Category = "Agent|Movement")
	inline float GetMinSpeed() { return MinSpeed; };
	// Setting Min/Max Speed
	UFUNCTION(BlueprintCallable, Category = "Agent|Movement")
	void SetMaxSpeed(float NewMaxSpeed);
	UFUNCTION(BlueprintCallable, Category = "Agent|Movement")
	void SetMinSpeed(float NewMinSpeed);

// Steering
protected:
	// Behaviour force strengths
	UPROPERTY(EditAnywhere, Category = "Agent|Steering")
	float AlignmentStrength;
	UPROPERTY(EditAnywhere, Category = "Agent|Steering")
	float SeparationStrength;
	UPROPERTY(EditAnywhere, Category = "Agent|Steering")
	float CohesionStrength;
	UPROPERTY(EditAnywhere, Category = "Agent|Steering")
	float AvoidanceStrength;

public:
	// Getting behavioural strenghts
	UFUNCTION(BlueprintCallable, Category = "Agent|Steering")
	inline float GetCohesionStrength() { return CohesionStrength; };
	UFUNCTION(BlueprintCallable, Category = "Agent|Steering")
	inline float GetAvoidanceStrength() { return AvoidanceStrength; };
	UFUNCTION(BlueprintCallable, Category = "Agent|Steering")
	inline float GetAlignmentStrength() { return AlignmentStrength; };
	UFUNCTION(BlueprintCallable, Category = "Agent|Steering")
	inline float GetSeparationStrength() { return SeparationStrength; };

	// Setting behavioural strengths
	UFUNCTION(BlueprintCallable, Category = "Agent|Steering")
	void SetCohesionStrength(float NewCohesionStrength);
	UFUNCTION(BlueprintCallable, Category = "Agent|Steering")
	void SetAvoidanceStrength(float NewAvoidanceStrength);
	UFUNCTION(BlueprintCallable, Category = "Agent|Steering")
	void SetAlignmentStrength(float NewAlignmentStrength);
	UFUNCTION(BlueprintCallable, Category = "Agent|Steering")
	void SetSeparationStrength(float NewSeparationStrength);


// Perception
protected:
	// Variables to determine the perception field FOV when a flockmate has been sensed 
	// 1.0 = Directly in front
	// -1.0 = Sense in all directions
	UPROPERTY(EditAnywhere, Category = "Agent|Perception", meta = (ClampMin = "-1.0", ClampMax = "1.0"))
	float SeparationFOV;
	UPROPERTY(EditAnywhere, Category = "Agent|Perception", meta = (ClampMin = "-1.0", ClampMax = "1.0"))
	float AlignmentFOV;
	UPROPERTY(EditAnywhere, Category = "Agent|Perception", meta = (ClampMin = "-1.0", ClampMax = "1.0"))
	float CohesionFOV;

public:
	// Getting behavioural FOVs
	UFUNCTION(BlueprintCallable, Category = "Agent|Perception")
	inline float GetSeparationFOV() { return SeparationFOV; };
	UFUNCTION(BlueprintCallable, Category = "Agent|Perception")
	inline float GetAlignmentFOV() { return AlignmentFOV; };
	UFUNCTION(BlueprintCallable, Category = "Agent|Perception")
	inline float GetCohesionFOV() { return CohesionFOV; };

// Avoidance
protected:
	// Amount of avoidance sensors
	UPROPERTY(EditAnywhere, Category = "Agent|Avoidance", meta = (ClampMin = "0", ClampMax = "1000"))
	int32 NumSensors;
	// Golden ration used for the avoidance sensor points on agents
	const float GoldenRatio = (1.0f + FMath::Sqrt(5.0f)) / 2;
	// Set amount of collision sensors
	UPROPERTY(EditAnywhere, Category = "Agent|Avoidance", meta = (ClampMin = "0"))
	float SensorRad;
	// Array of avoidance sensors
	TArray<FVector> AvoidanceSensors;
	// Builds the avoidance sensor directions
	void BuildAvoidanceSensors();

public:
	// Avoidance Getters
	inline float GetSensorRadius() { return SensorRad; }
	inline TArray<FVector> GetAvoidanceSensors() { return AvoidanceSensors; }
};