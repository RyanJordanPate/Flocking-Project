

// Actor spawned into the world which exhibits bird like flocking behaviours
// Within this class, the Behaviour, Movement and collision queries are calculated and set to the Agents Velocity Vector and Rotation Vector

#pragma once

// includes
#include "CoreMinimal.h"
#include "GameFramework/Actor.h"
#include "Agent.generated.h"

class USphereComponent;
class UStaticMeshComponent;
class UArrowComponent;
class AAgentSimManager;

UCLASS()
class AGENTFLOCKING_API AAgent : public AActor
{
	GENERATED_BODY()

public:
	// Default Constructor
	AAgent();
	
	// Called to update each frame
	virtual void Tick(float DeltaTime) override;

protected:
	// Called on level start or when spawned
	virtual void BeginPlay() override;

// Components
protected:
	// Agent collision component
	// Used for collision checks to see if the Agent is within another actor/object
	UPROPERTY(VisibleAnywhere, Category = "Agent|Components")
	USphereComponent* AgentCollision;

	// Agent static mesh component
	// Used to create the agents spherical body
	UPROPERTY(VisibleAnywhere, Category = "Agent|Components")
	UStaticMeshComponent* AgentMesh;

	// Perception sensor used to see if there are any neighbours within a agents surrounding
	// Will be used within all of the behavioural rule calculations, deciding what agents are close enough to compare
	UPROPERTY(VisibleAnywhere, Category = "Agent|Components")
	USphereComponent* PerceptionSensor;

	// Arrow component to show where the agent is facing
	UPROPERTY(VisibleAnywhere, Category = "Agent|Components")
	UArrowComponent* DirectionalArrow;

// Agent Sim Manager
protected:
	// Agent manager pointer that controls the Agents behaviours (Cohesion, Alignment, Separation)
	AAgentSimManager* AgentSimManager;

public:
	inline AAgentSimManager* GetAgentSimManager() { return AgentSimManager; }

// Movement Mechanics
protected:
	// Agents Velocity
	// Set to the Agents default forward vector which is changed dependent on behavioural force outputs
	// This vector is multiplied by the speed of the agents, updating their position on the map
	FVector AgentVelocity;

	// Agents rotation on tick to allow for smooth navigational movement
	// Using interp to smoothly turn the agent
	FRotator AgentRotation;

	// Smoothly update the Agents rotation to follow the velocity
	void UpdateAgentRotation();

// Agent Steering Mechanics
protected:
	// Returning cohesion steering forces so agents can move to the average position of local neighbours
	FVector Cohesion(TArray<AActor*> Flock);
	// Returning separation steering forces so collisions can be avoided with local neighbours
	FVector	Separation(TArray<AActor*> Flock);
	// Returning alignment steering forces so agents can move to the average heading of local neighbours
	FVector Alignment(TArray<AActor*> Flock);
	// Apply behaviours to the Agent and update its movement
	void Steer(float DeltaTime);

// Avoidance Agent Mechanics
protected:
	// Finding if agent is on a imminent collision course
	bool ImminentCollision();
	// Returning obstacle avoidance force so agent can avoid collisions
	FVector AvoidCollision();

public:

	UFUNCTION(BlueprintCallable)
	inline FVector GetAgentVelocity() { return AgentVelocity; };



};

