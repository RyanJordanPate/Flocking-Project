

// An actor that can be placed in the world to spawn and contain Agents in a designated area.
// Agents that leave the box boundary are teleported to the other side.


#pragma once

//includes
#include "CoreMinimal.h"
#include "GameFramework/Actor.h"
#include "AgentSpawner.generated.h"

//forward declares
class AAgent;
class AAgentSimManager;
class UBoxComponent; 


UCLASS()
class AGENTFLOCKING_API AAgentSpawner : public AActor
{
	GENERATED_BODY()

public:
	//default constructor used to set initial properties
	AAgentSpawner();

protected:
	//setup logic called when level starts or spawned
	virtual void BeginPlay() override;

// Components
protected:
	// Creating collision component which will keep all the Agents within
	UPROPERTY(VisibleAnywhere, BlueprintReadOnly, Category = "Agent|Components")
	UBoxComponent* BoxCollision;

// Collision overlap events
protected:
	// Checking if the agent has left the preset bounds
	// Will be used to spawn the agent on the opposite side
	UFUNCTION()
	void OnBoxOverlapEnd(UPrimitiveComponent* OverlappedComponent, AActor* OtherActor, UPrimitiveComponent* OtherComp, int32 OtherBodyIndex);

// Agent Spawning
public:
	// The amount of initial agents to spawn in the bounds
	UPROPERTY(EditAnywhere, Category = "Agent|Spawn", meta = (ClampMin = "0", ClampMax = "1600"))
	int32 AgentsToSpawn;

	// Type of Agent to spawn
	UPROPERTY(EditAnywhere, Category = "Agent|Spawn")
	TSubclassOf<AAgent> AgentType;

	// Spawn the agents in the bounds
	void SpawnAgents(int NumAgents);

	// Sim manager pointer for checks
	UPROPERTY(EditAnywhere, Category = "Agent|Spawn")
	AAgentSimManager* AssignedAgentSimManager;
};
