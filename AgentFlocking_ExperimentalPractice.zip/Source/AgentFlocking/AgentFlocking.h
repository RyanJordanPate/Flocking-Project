// Copyright Epic Games, Inc. All Rights Reserved.

#pragma once
#include "CoreMinimal.h"
#define AGENT_COLLISION_AVOIDANCE ECC_GameTraceChannel1